import React, { useState } from 'react';
import './homestyle.css';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const CreateAccount = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [dob, setDob] = useState('');
  const [email, setEmail] = useState('');
  const navigate = useNavigate();

  const togglePassword = () => {
    setShowPassword(prev => !prev);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    handleLogin();
  };

  const handleLogin = async () => {
    if (
      username.trim() === '' ||
      password.trim() === '' ||
      dob.trim() === '' ||
      email.trim() === ''
    ) {
      alert('Please fill in all fields!');
      return;
    }

    try {
      const res = await axios.post('http://localhost:5000/api/register', {
        username,
        password,
        dob,
        email,
      });

      console.log(res.data);

      const loginInfo = {
        username,
        isAuthenticated: true,
      };

      navigate('/Menu', { state: { loginInfo } });
    } catch (err) {
      console.error('Login failed:', err);
      alert('Username already exist');
    }
  };

  return (
    <div className="sweet-treats-container">
      <section className="sweet-treats-background-section"></section>
      <div className="sweet-treats-login-container">
        <h2>Create an account</h2>
        <form onSubmit={handleSubmit}>
  <div className="sweet-treats-input-group">
    <label htmlFor="username">Username</label>
    <input
      type="text"
      id="username"
      placeholder="Enter your username"
      value={username}
      onChange={(e) => setUsername(e.target.value)}
      required
    />
  </div>

  <div className="sweet-treats-input-group">
    <label htmlFor="email">Email Address</label>
    <input
      type="email"
      id="email"
      placeholder="Enter your email"
      value={email}
      onChange={(e) => setEmail(e.target.value)}
      required
    />
  </div>

  <div className="sweet-treats-input-group">
    <label htmlFor="dob">Date of Birth</label>
    <input
      type="date"
      id="dob"
      value={dob}
      onChange={(e) => setDob(e.target.value)}
      required
    />
  </div>

  <div className="sweet-treats-input-group">
    <label htmlFor="password">Password</label>
    <div className="sweet-treats-password-container">
      <input
        type={showPassword ? 'text' : 'password'}
        id="password"
        placeholder="Enter your password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <span
        className="sweet-treats-toggle-password"
        onClick={togglePassword}
      >
        👁️
      </span>
    </div>
  </div>

  <button type="submit" className="sweet-treats-login-button">Submit</button>
</form>
</div>
</div>
  );
};
export default CreateAccount;
