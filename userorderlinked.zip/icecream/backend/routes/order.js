const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
// const User = require('../models/User');
// const MenuItem = require('../models/MenuItem');

// Test route to verify API is working
router.get('/test', (req, res) => {
  res.json({ message: 'API is working!' });
  console.log("hello");
});

const User = require('../models/User');

router.post('/place-order', async (req, res) => {
  const { userId, items, totalPrice } = req.body;

  try {
    // Find the user by userId
    const user = await User.findById(userId);
    if (!user) {
      return res.status(400).json({ message: 'User not found' }); // Send error if user doesn't exist
    }

    // Proceed with creating the order
    const newOrder = new Order({
      userId,
      items,
      totalPrice,
    });

    await newOrder.save();
    res.status(201).json({ message: 'Order placed successfully!', order: newOrder });
  } catch (error) {
    console.error('Error placing order:', error);
    res.status(500).json({ message: 'Error placing order', error: error.message });
  }
});

module.exports = router;
