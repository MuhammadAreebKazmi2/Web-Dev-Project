const mongoose = require('mongoose');

// defining order schema
// Define the order schema
const orderSchema = new mongoose.Schema({
    userId: {type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true},
    items: [
      {
        name: String,
        price: Number,
        quantity: Number,
        selectedBase: String,
        selectedToppings: [String], // Array of selected toppings (IDs)
      }
    ],
    totalPrice: Number, // Total price of the order
    createdAt: { type: Date, default: Date.now },
});
  
module.exports = mongoose.model('Order', orderSchema);
  